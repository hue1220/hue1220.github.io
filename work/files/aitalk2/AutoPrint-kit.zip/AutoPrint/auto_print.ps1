﻿# 자동 인쇄 (학교 PC용) - 2회 AI 토킹모임 키트
# GitHub 인쇄함 저장소의 print 폴더에서 아직 안 뽑은 .html/.pdf 파일을 내려받아
# (html이면 엣지/크롬을 화면 없이 써서 PDF로 바꾼 뒤) SumatraPDF로 인쇄합니다.
# 파일 이름에 _흑백 이 있으면 흑백, _양면 이 있으면 양면으로 인쇄합니다. (기본: 컬러, 단면)
param([switch]$Force)

$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$Root    = Join-Path $env:USERPROFILE 'AutoPrint'
$Inbox   = Join-Path $Root 'files'
$LogFile = Join-Path $Root 'log.txt'
$Done    = Join-Path $Root 'printed.txt'
$Folder  = 'print'
New-Item -ItemType Directory -Force -Path $Inbox | Out-Null
if (-not (Test-Path $Done)) { New-Item -ItemType File -Path $Done | Out-Null }

function Log($msg) {
  $line = '{0}  {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $msg
  Add-Content -Path $LogFile -Value $line -Encoding UTF8
  Write-Host $line
}

function Run-Exe($exe, $argList, $timeoutSec) {
  $p = Start-Process -FilePath $exe -ArgumentList $argList -WindowStyle Hidden -PassThru
  if (-not $p.WaitForExit($timeoutSec * 1000)) {
    try { $p.Kill() } catch {}
    Log "시간 초과로 정리함: $(Split-Path $exe -Leaf)"
  }
}

function Find-Exe($candidates) {
  foreach ($c in $candidates) { if ($c -and (Test-Path $c)) { return $c } }
  return $null
}

try {
  $Repo  = (Get-Content (Join-Path $Root 'repo.txt') -Raw).Trim()
  $token = (Get-Content (Join-Path $Root 'token.txt') -Raw).Trim()
  $headers = @{ Authorization = "Bearer $token"; 'User-Agent' = 'aitalk-auto-print'; 'X-GitHub-Api-Version' = '2022-11-28' }

  $browser = Find-Exe @(
    "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
    "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
    "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe")
  $sumatra = Find-Exe @(
    "$env:LOCALAPPDATA\SumatraPDF\SumatraPDF.exe",
    "$env:ProgramFiles\SumatraPDF\SumatraPDF.exe",
    "${env:ProgramFiles(x86)}\SumatraPDF\SumatraPDF.exe",
    (Join-Path $Root 'SumatraPDF.exe'))
  if (-not $sumatra) { throw 'SumatraPDF를 찾지 못했어요. 먼저 설치해 주세요.' }

  $printerFile = Join-Path $Root 'printer.txt'
  $printer = if (Test-Path $printerFile) { (Get-Content $printerFile -Raw).Trim() } else { '' }

  try {
    $list = Invoke-RestMethod -Uri "https://api.github.com/repos/$Repo/contents/$Folder" -Headers $headers
  } catch {
    $code = $_.Exception.Response.StatusCode.value__
    if ($code -eq 404) { Log "인쇄함에 print 폴더가 아직 없어요 (저장소: $Repo)"; exit 0 }
    if ($code -eq 401) { throw '토큰이 틀렸거나 만료됐어요. 새 토큰을 만들어 token.txt를 바꿔 주세요.' }
    throw
  }
  $printed = @(Get-Content $Done -Encoding UTF8)
  $todo = @($list | Where-Object { $_.type -eq 'file' -and $_.name -match '\.(html|pdf)$' -and ($Force -or $printed -notcontains $_.name) } | Sort-Object name)

  if ($todo.Count -eq 0) { Log '새로 인쇄할 파일 없음'; exit 0 }

  foreach ($f in $todo) {
    $local = Join-Path $Inbox $f.name
    Invoke-WebRequest -Uri $f.url -Headers ($headers + @{ Accept = 'application/vnd.github.raw' }) -OutFile $local -UseBasicParsing
    $pdf = $local
    if ($f.name -match '\.html$') {
      if (-not $browser) { throw '엣지나 크롬을 찾지 못했어요.' }
      $pdf = [IO.Path]::ChangeExtension($local, '.pdf')
      if (Test-Path $pdf) { Remove-Item $pdf -Force }
      $url = 'file:///' + ($local -replace '\\','/')
      $bargs = @('--headless=new','--disable-gpu','--no-first-run','--no-pdf-header-footer',
                "--user-data-dir=`"$Root\browser-profile`"",'--virtual-time-budget=20000',
                "--print-to-pdf=`"$pdf`"", "`"$url`"")
      Run-Exe $browser $bargs 90
      if (-not (Test-Path $pdf)) { throw "PDF 만들기 실패: $($f.name)" }
    }
    $pargs = @()
    if ($printer) { $pargs += @('-print-to', "`"$printer`"") } else { $pargs += '-print-to-default' }
    $duplex = if ($f.name -match '_(양면|duplex)') { 'duplexlong' } else { 'simplex' }
    $color  = if ($f.name -match '_(흑백|bw)') { 'monochrome' } else { 'color' }
    $pargs += @('-print-settings', "$duplex,$color", '-silent', "`"$pdf`"")
    Run-Exe $sumatra $pargs 120
    Add-Content -Path $Done -Value $f.name -Encoding UTF8
    Log "인쇄 보냄: $($f.name)  [$duplex,$color]  (프린터: $(if ($printer) { $printer } else { '기본 프린터' }))"
  }
}
catch {
  Log "오류: $($_.Exception.Message)"
  exit 1
}
