﻿# 자동 인쇄 - 처음 한 번 설치 (2회 AI 토킹모임 키트)
$ErrorActionPreference = 'Stop'
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root = Join-Path $env:USERPROFILE 'AutoPrint'
New-Item -ItemType Directory -Force -Path $Root | Out-Null

Write-Host ''
Write-Host '=== 자동 인쇄 설치 ===' -ForegroundColor Cyan

# 1. 프로그램 복사
Copy-Item (Join-Path $Here 'auto_print.ps1') (Join-Path $Root 'auto_print.ps1') -Force
Write-Host "1) 프로그램을 $Root 에 넣었어요."

# 2. SumatraPDF 확인
$sumatra = @("$env:LOCALAPPDATA\SumatraPDF\SumatraPDF.exe", "$env:ProgramFiles\SumatraPDF\SumatraPDF.exe", "${env:ProgramFiles(x86)}\SumatraPDF\SumatraPDF.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($sumatra) { Write-Host "2) SumatraPDF 확인: $sumatra" }
else { Write-Host '2) SumatraPDF가 아직 없어요. sumatrapdfreader.org 에서 설치한 뒤 이 설치를 다시 실행해 주세요.' -ForegroundColor Yellow; Read-Host 'Enter를 누르면 닫혀요'; exit 1 }

# 3. 인쇄함 저장소 이름
$repoFile = Join-Path $Root 'repo.txt'
$r = Read-Host '3) 인쇄함 저장소를 "GitHub아이디/저장소이름" 으로 입력하고 Enter (예: hong123/print-box)'
Set-Content -Path $repoFile -Value $r.Trim() -NoNewline

# 4. GitHub 토큰(출입증)
$tokenFile = Join-Path $Root 'token.txt'
$t = Read-Host '4) GitHub 토큰을 붙여넣고 Enter (github_pat_ 로 시작)'
Set-Content -Path $tokenFile -Value $t.Trim() -NoNewline

# 5. 프린터 고르기
$printers = @(Get-Printer | Select-Object -ExpandProperty Name)
Write-Host '5) 이 PC의 프린터:'
for ($i = 0; $i -lt $printers.Count; $i++) { Write-Host ("   [{0}] {1}" -f ($i + 1), $printers[$i]) }
$n = Read-Host '   쓸 프린터 번호를 입력하고 Enter (그냥 Enter = 기본 프린터)'
if ($n -match '^\d+$' -and [int]$n -ge 1 -and [int]$n -le $printers.Count) {
  Set-Content -Path (Join-Path $Root 'printer.txt') -Value $printers[[int]$n - 1] -NoNewline
  Write-Host "   -> $($printers[[int]$n - 1])"
}

# 6. 인쇄 시각
$at = Read-Host '6) 매일 인쇄할 시각을 입력하고 Enter (예: 13:00, 그냥 Enter = 13:00)'
if ($at -notmatch '^\d{1,2}:\d{2}$') { $at = '13:00' }
$base = [datetime]::ParseExact($at.PadLeft(5,'0'), 'HH:mm', $null)
$times = @($base, $base.AddMinutes(20), $base.AddMinutes(40))

# 7. 작업 스케줄러 등록: 평일, 시각 + 20분 뒤 + 40분 뒤 (이미 뽑은 건 다시 안 뽑음)
$action  = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$Root\auto_print.ps1`""
$days    = 'Monday','Tuesday','Wednesday','Thursday','Friday'
$trigger = $times | ForEach-Object { New-ScheduledTaskTrigger -Weekly -DaysOfWeek $days -At $_ }
$set     = New-ScheduledTaskSettingsSet -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 15)
Register-ScheduledTask -TaskName 'AutoPrint' -Action $action -Trigger $trigger -Settings $set -Force | Out-Null
Write-Host ("7) 작업 스케줄러에 'AutoPrint' 를 등록했어요. 평일 {0} · {1} · {2}" -f $times[0].ToString('HH:mm'), $times[1].ToString('HH:mm'), $times[2].ToString('HH:mm'))

# 8. 지금 시험 실행
Write-Host '8) 지금 한 번 실행해 볼게요...'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $Root 'auto_print.ps1')
Write-Host ''
Write-Host '끝! 아래 기록을 확인하세요:' -ForegroundColor Cyan
Get-Content (Join-Path $Root 'log.txt') -Tail 5
Read-Host '창을 닫으려면 Enter'
